# Instructions you can give your existing coding assistant

I want to try this kit on its synthetic examples before using it in my project.
Read START-HERE.html, SETUP.md and the selected workflow's READ-ME.md. Explain
in plain language which files you will create and which local commands you will
run. Use a fresh local Python 3.12+ environment with exactly INVARA 0.2.0. Do
not change my real project, system settings or existing result folders.

Run the selected example and report the original engine verdict, its declared
scope, what was not checked, and the location of the raw output. Do not treat a
successful process exit as PASS. A planned change to a protected synthetic
file should remain BLOCK, even when that is the expected teaching result.

For my own task later, identify the real existing files to protect and real
commands that provide evidence. Show the proposed plan before sealing it and
before making the requested change. Do not invent successful checks, silently
weaken the conditions, upload my project, auto-accept work, deploy or publish.
If a usable before state or check is missing, name that missing prerequisite.
