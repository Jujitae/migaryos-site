# Set up once, then keep the examples local

Start by opening START-HERE.html. You can read it without installing anything.
To run the examples, use a computer with Python 3.12 or later. Keep this folder
outside a live project. Ask your coding assistant to show the steps it will
run, use a fresh local environment, and install exactly INVARA 0.2.0.

The following commands are an optional manual path. Open a terminal in the
unpacked kit folder. Installing from PyPI needs internet access and may not be
available until the exact 0.2.0 release is public. If it is unavailable, stop;
do not silently substitute a different version or an unknown download.

## Windows

```powershell
py -3.12 -m venv .venv
.\.venv\Scripts\python.exe -m pip install invara==0.2.0
.\.venv\Scripts\python.exe run_example.py feature
.\.venv\Scripts\python.exe run_example.py feature --case changed
```

## Linux manual path — not executed by this kit producer

```sh
python3.12 -m venv .venv
.venv/bin/python -m pip install invara==0.2.0
.venv/bin/python run_example.py feature
.venv/bin/python run_example.py feature --case changed
```

This producer tested the examples on Windows, not a Linux host. The engine has
separate Linux evidence; that does not substitute for a kit execution record.
macOS is not verified. Paths with spaces are supported by the example runner.

An organization with the official wheel can instead install that exact local
file with `python -m pip install --no-index --no-deps <wheel-file>`. Do not trust
a file just because its name says 0.2.0. The sealed wheel expected for this kit
has SHA256:

`2a4d2fb7d3716b66abcac1aec826fa0c2ba696b9633912e8a9e4c9756c5af393`

The runner refuses an absent/different INVARA version. It does not install,
upgrade, edit your real project or delete an earlier result. Each execution
creates a new local `runs/` folder with raw outputs and a summary.
