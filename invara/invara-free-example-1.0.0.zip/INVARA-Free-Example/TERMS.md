# Complete free example

This complete feature example is free. No payment, account, email signup or paid
kit is required. It uses the MIT License in LICENSE.txt. The checker remains
separately free under Apache-2.0 and is not bundled. No human review or hosted
service is promised. Read SETUP.md, PRIVACY.md and OUTCOMES.md before running.
