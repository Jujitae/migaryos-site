# Synthetic example outcomes — producer summary

These are newly executed teaching examples, not customer outcomes. This is a
human-readable derived summary, not the original raw receipts or independent
approval. The original private producer receipts are retained separately.

Observed environment: Windows / Python 3.12.10 / INVARA 0.2.0 installed from
the fixed sealed wheel. The installed 33 Python modules matched that wheel.

| Example | Original verdict | Process exit | Expected teaching outcome observed |
|---|---|---|---|
| feature-kept | PASS | 0 | yes |
| feature-changed | BLOCK | 1 | yes |

This feature example covers two protected check files and their command exits.
Other inputs, performance, security, user interfaces and real customer projects
are not checked. BLOCK stays BLOCK when the saved result is replayed.

A new local run writes the user's own original report and receipts. Those files
can contain local usernames, file paths and commands; do not upload them blindly.
