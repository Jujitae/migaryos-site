# Read the result without turning it into a promise

| Result | What to do next |
|---|---|
| PASS | Read which conditions were checked and the limits. Decide yourself whether more checks or a person are needed. |
| BLOCK | Read the failed condition or observed difference. Keep the original record and correct the work, not the expectation merely to get green. |
| UNVERIFIABLE | Find the missing command, file or observation. Restore the prerequisite and use a fresh, correctly scoped check. Unchecked is not passed. |
| HUMAN_REVIEW | A person must review the stated issue. Exit code zero does not make this PASS. |
| REFUSED / runner error | The requested operation did not finish as a usable verdict. Read the reason; do not label it BLOCK or PASS. |

## Common, recoverable problems

- **Python or INVARA is missing:** follow SETUP.md or ask your local assistant
  to create a separate environment. Do not edit a system installation blindly.
- **Wrong INVARA version:** use the exact 0.2.0 version in a fresh environment.
  The runner intentionally stops rather than guessing compatibility.
- **Output folder already exists:** choose a new folder or omit `--output`.
  Previous evidence is preserved; the runner never empties that folder for you.
- **Protected file is missing:** select a real file before sealing. Creating
  an imaginary successful check is not a repair.
- **A command cannot run:** UNVERIFIABLE describes missing evidence. Install
  or repair the legitimate prerequisite; do not replace it with `exit 0`.
- **The changed-file example returns BLOCK:** this is the intended teaching
  result. A comment was added to a protected file; byte preservation includes
  comments and line endings, even when the tests still run successfully.
- **The before/after example returns BLOCK:** inspect the stated input and
  output difference. It is a synthetic functional change, not a security test.
- **A report cannot be written:** check disk permissions or choose a new
  writable output directory. Keep the command output instead of claiming a
  report exists.

The example runner's process code depends on whether a supported example
reaches completion. For a normal run of a supported example that writes the
wrapper's `result.json`, exit 0 means the expected PASS case completed and exit
1 means the expected BLOCK case completed. Command-line parsing is separate:
`--help` exits 0 without running an example or writing wrapper `result.json`;
a missing or invalid workflow exits 2 without running an example or writing
wrapper `result.json`. After parsing, exit 3 means the wrapper did not complete
a supported example because setup, engine execution, output creation or
expected-example verification failed. This fixed teaching runner accepts only
its expected PASS or BLOCK cases. If the engine reports an unexpected
UNVERIFIABLE or HUMAN_REVIEW, the wrapper returns 3 and does not write its
`result.json` completed-example summary. Underlying engine `report.json`,
`report.md` and command receipts may already have been written; the wrapper
preserves them. For a completed supported example, wrapper `result.json`
records the original engine verdict and whether the synthetic expected result
was observed. An expected BLOCK is never relabeled PASS.
