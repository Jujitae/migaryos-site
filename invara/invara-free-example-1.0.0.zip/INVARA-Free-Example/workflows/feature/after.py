"""Synthetic teaching program with a small new feature."""
def greet(name):
    return "Hello, " + name + "!"

def greet_many(names):
    return [greet(name) for name in names]
