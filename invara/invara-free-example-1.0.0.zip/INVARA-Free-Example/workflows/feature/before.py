"""Synthetic teaching program; no customer data."""
def greet(name):
    return "Hello, " + name + "!"
