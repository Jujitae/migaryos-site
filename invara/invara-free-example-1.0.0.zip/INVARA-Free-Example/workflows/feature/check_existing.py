"""Synthetic agreed check. Keep this file byte-identical after sealing."""
from app import greet
if greet("Ada") != "Hello, Ada!":
    raise SystemExit("SYNTHETIC existing greeting did not match")
print("SYNTHETIC existing greeting matched")
