"""Synthetic new-feature condition agreed before the work."""
from app import greet_many
if greet_many(["Ada", "Bo"]) != ["Hello, Ada!", "Hello, Bo!"]:
    raise SystemExit("SYNTHETIC list greeting did not match")
print("SYNTHETIC list greeting matched")
