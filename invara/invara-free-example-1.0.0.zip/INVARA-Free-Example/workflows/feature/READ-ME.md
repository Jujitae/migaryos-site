# Add a small feature without changing the agreed checks

**Synthetic example. No customer project or result is used.**

A tiny greeting program already greets one name. The requested feature greets
a list of names. Before the change, the plan protects the existing and new
acceptance checks. The example then adds the feature and asks INVARA to judge.

Open `contract.template.json` to see the editable plan. It names real example
files, not a quality score. The runner copies the example into a new folder,
fills the local interpreter path, seals before changing app.py, and records
the exact result. It does not touch your other projects.

Try the normal example: `python run_example.py feature`. The expected result
is PASS: both checks run and their protected bytes are unchanged.

Try `python run_example.py feature --case changed`. The feature still works,
but the runner adds a labeled comment to a protected check *after sealing*.
The expected result is BLOCK. This demonstrates a broken declared condition,
not malicious behavior or a vulnerability.

## Adapt it to your own task

Ask your local assistant to identify the existing files that must stay
unchanged and the commands that actually test the requested behavior. Read its
plain-language explanation and the commands before it runs them. Replace the
example names and paths with real ones, choose a new task ID, and seal before
the work starts. A line of intent alone is not an executable check.

If there is no trustworthy pre-work state or usable existing check, stop and
name that gap. Do not call a retrospective check proof that a past promise
was kept. You can use this complete feature example and the free engine
without buying any other kit material.
