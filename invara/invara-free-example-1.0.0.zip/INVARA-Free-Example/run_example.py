"""Run only this kit's benign synthetic examples in a fresh local folder.

No installation, network request, source upload, auto-acceptance or deletion.
New kit material is MIT-licensed. The separately installed INVARA remains free.
"""
from __future__ import annotations
import argparse
import datetime as dt
import hashlib
import importlib.metadata
import importlib.util
import json
import os
from pathlib import Path
import re
import shutil
import subprocess
import sys
import uuid

BASE = Path(__file__).resolve().parent

def write_json(path: Path, value: object) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(value, indent=2, ensure_ascii=False) + "\n", encoding="utf-8")

def file_hash(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()

def child_environment() -> dict[str, str]:
    names = ("PATH", "SYSTEMROOT", "SYSTEMDRIVE", "WINDIR", "PATHEXT", "COMSPEC", "TEMP", "TMP", "HOME", "USERPROFILE")
    result = {name: os.environ[name] for name in names if name in os.environ}
    result.update(PYTHONNOUSERSITE="1", PYTHONDONTWRITEBYTECODE="1", PYTHONUTF8="1")
    return result

class ExampleRun:
    def __init__(self, output: Path):
        self.output = output
        self.receipts = output / "receipts"
        self.receipts.mkdir(parents=True)
        self.operations: list[dict] = []

    def cli(self, name: str, args: list[str], *, cwd: Path, allowed: tuple[int, ...] = (0,)) -> subprocess.CompletedProcess:
        argv = [sys.executable, "-I", "-m", "invara", *args]
        record = {"operation": name, "argv": argv, "cwd": str(cwd), "synthetic": True,
                  "started_utc": dt.datetime.now(dt.UTC).isoformat()}
        try:
            value = subprocess.run(argv, cwd=cwd, env=child_environment(), capture_output=True,
                                   encoding="utf-8", errors="replace", timeout=90, check=False)
        except (OSError, subprocess.TimeoutExpired) as error:
            record.update(error=str(error), completed=False)
            write_json(self.receipts / f"{name}.command.json", record)
            raise RuntimeError(f"{name} did not complete; read its local receipt") from error
        (self.receipts / f"{name}.stdout.txt").write_text(value.stdout, encoding="utf-8")
        (self.receipts / f"{name}.stderr.txt").write_text(value.stderr, encoding="utf-8")
        record.update(returncode=value.returncode, completed=True,
                      stdout_sha256=file_hash(self.receipts / f"{name}.stdout.txt"),
                      stderr_sha256=file_hash(self.receipts / f"{name}.stderr.txt"))
        write_json(self.receipts / f"{name}.command.json", record)
        self.operations.append(record)
        if value.returncode not in allowed:
            raise RuntimeError(f"{name} exited {value.returncode}; read receipts/{name}.stdout.txt and .stderr.txt")
        return value

def feature(run: ExampleRun, changed: bool) -> dict:
    template = BASE / "workflows" / "feature"
    project = run.output / "example-project"
    project.mkdir()
    shutil.copyfile(template / "before.py", project / "app.py")
    for name in ("check_existing.py", "check_feature.py"):
        shutil.copyfile(template / name, project / name)
    spec = json.loads((template / "contract.template.json").read_text(encoding="utf-8"))
    spec["task_id"] += "-changed" if changed else "-kept"
    for check in spec["done_when"]:
        check["command"][0] = sys.executable
    task_file = run.output / "task.json"
    write_json(task_file, spec)
    database = run.output / "evidence.db"
    shared = ["--db", str(database), "--root", str(project)]
    run.cli("01-seal", ["seal", str(task_file), *shared], cwd=project)
    shutil.copyfile(template / "after.py", project / "app.py")
    if changed:
        protected = project / "check_existing.py"
        with protected.open("ab") as stream:
            stream.write(b"\n# SYNTHETIC teaching change added after sealing.\n")
    judged = run.cli("02-judge", ["judge", spec["task_id"], "--commit", *shared], cwd=project, allowed=(0, 1, 2))
    match = re.search(r"^  (PASS|BLOCK|UNVERIFIABLE|HUMAN_REVIEW):", judged.stdout, re.M)
    if not match:
        raise RuntimeError("No exact engine verdict found in the judge output")
    verdict = match.group(1)
    expected = "BLOCK" if changed else "PASS"
    if verdict != expected or judged.returncode != (1 if changed else 0):
        raise RuntimeError(f"Synthetic expectation was {expected}; actual engine result was {verdict}")
    run.cli("03-list", ["list", *shared], cwd=project)
    run.cli("04-log", ["log", spec["task_id"], *shared], cwd=project)
    chain = run.cli("05-chain", ["chain", *shared], cwd=project)
    replay = run.cli("06-replay", ["replay", spec["task_id"], *shared], cwd=project)
    return {"workflow": "feature", "case": "changed" if changed else "kept", "verdict": verdict,
            "engine_exit_code": judged.returncode, "expected_verdict": expected,
            "expected_outcome_observed": True,
            "declared_scope": "Two protected Python check files and their exit codes in a synthetic greeting feature",
            "not_checked": ["General correctness", "Security", "User interface", "Any customer project"],
            "chain_output": chain.stdout.strip(), "replay_output": replay.stdout.strip()}

def comparison(run: ExampleRun, changed: bool, handoff: bool) -> dict:
    template = BASE / "workflows" / "before-after"
    before, after = run.output / "before", run.output / "after"
    before.mkdir()
    after.mkdir()
    shutil.copyfile(template / "before.py", before / "label.py")
    shutil.copyfile(template / ("changed.py" if changed else "after.py"), after / "label.py")
    manifest = json.loads((template / "manifest.template.json").read_text(encoding="utf-8"))
    manifest["session_id"] += "-handoff" if handoff else ("-changed" if changed else "-matching")
    for key in ("source_system", "target_system"):
        manifest[key]["command"][0] = sys.executable
    manifest_file = run.output / "manifest.json"
    write_json(manifest_file, manifest)
    database = run.output / "evidence.db"
    json_report, md_report = run.output / "report.json", run.output / "report.md"
    expected = "BLOCK" if changed else "PASS"
    expected_exit = 1 if changed else 0
    executed = run.cli("01-assure-run", ["assure", "run", "--manifest", str(manifest_file),
                      "--source-root", str(before), "--target-root", str(after),
                      "--workspace", str(run.output / "workspace"), "--runs", "1",
                      "--db", str(database), "--json", str(json_report), "--md", str(md_report)],
                      cwd=run.output, allowed=(0, 1, 2))
    report = json.loads(json_report.read_text(encoding="utf-8"))
    verdict = report["summary"]["verdict"]["status"]
    if verdict != expected or executed.returncode != expected_exit:
        raise RuntimeError(f"Synthetic expectation was {expected}; actual engine result was {verdict}")
    run.cli("02-assure-verify", ["assure", "verify", manifest["session_id"], "--require", "PASS", "--db", str(database)],
            cwd=run.output, allowed=(expected_exit,))
    archive = run.output / "evidence.zip"
    run.cli("03-assure-export", ["assure", "export", manifest["session_id"], "--out", str(archive), "--db", str(database)], cwd=run.output)
    inspected = run.cli("04-assure-inspect", ["assure", "inspect", str(archive)], cwd=run.output)
    inspection, json_end = json.JSONDecoder().raw_decode(inspected.stdout.lstrip())
    trailing = inspected.stdout.lstrip()[json_end:].strip().splitlines()
    expected_trailing = [
        f"store problem(s) carried from the exporting store: {len(inspection.get('store_problems') or [])}",
        f"INSPECT OK: {inspection['checks']['comparisons_agree']} comparison(s) recomputed and agreeing; verdict {inspection['verdict']['status']} re-derived",
    ]
    if trailing != expected_trailing:
        raise RuntimeError("Unexpected inspection output format; original output was preserved")
    if inspection.get("ok") is not True or inspection.get("verdict", {}).get("status") != verdict:
        raise RuntimeError("Export inspection did not preserve the original verdict and evidence consistency")
    result = {"workflow": "handoff" if handoff else "before-after", "case": "changed" if changed else "matching",
              "verdict": verdict, "engine_exit_code": executed.returncode, "expected_verdict": expected,
              "expected_outcome_observed": True, "declared_domain_members": 6,
              "declared_scope": "JSON labels and process exit observations for quantity [1,2,4] x style [plain,upper]",
              "not_checked": ["Other inputs", "Performance", "Security", "Any customer project"],
              "evidence_sha256": file_hash(archive),
              "inspection": {"ok": inspection["ok"], "verdict": inspection["verdict"]["status"], "checks": inspection["checks"]},
              "inspection_reruns_original_programs": False, "inspection_establishes_author_identity": False}
    if handoff:
        cover = ("# Synthetic task handoff — generated cover sheet\n\n"
                 "This is a teaching record, not a customer result or a certificate.\n\n"
                 f"Original engine verdict: **{verdict}**.\n\n"
                 "Scope: six quantity/style combinations; JSON label and process observations.\n\n"
                 "Not checked: other inputs, performance, security, real projects.\n\n"
                 "Original report: `report.json` and `report.md`. Evidence: `evidence.zip`.\n\n"
                 f"Evidence SHA256: `{result['evidence_sha256']}`.\n\n"
                 "Recipient recheck: with INVARA 0.2.0, run `invara assure inspect evidence.zip`.\n\n"
                 "Inspection recomputes recorded comparisons; it does not rerun code or prove authorship. "
                 "Confirm the file hash through a separately trusted channel. Review paths and contents before sharing.\n\n"
                 "Person's decision: not made by this cover sheet or by PASS.\n")
        (run.output / "HANDOFF.md").write_text(cover, encoding="utf-8")
    return result

def main() -> int:
    try:
        settings = json.loads((BASE / "kit.json").read_text(encoding="utf-8"))
        parser = argparse.ArgumentParser(description="Run a synthetic INVARA example locally; never edits a real project.")
        parser.add_argument("workflow", choices=settings["available_workflows"])
        parser.add_argument("--case", choices=("kept", "changed"), default="kept", help="changed is an intentional functional/declared-condition difference")
        parser.add_argument("--output", type=Path, help="A new local folder; an existing folder is never emptied or reused")
        args = parser.parse_args()
        if args.workflow == "handoff" and args.case == "changed":
            raise RuntimeError("The handoff teaching example uses matching output; use before-after --case changed to see a difference")
        if sys.version_info < (3, 12):
            raise RuntimeError("Python 3.12 or later is required; follow SETUP.md")
        installed = importlib.metadata.version("invara")
        if installed != "0.2.0":
            raise RuntimeError(f"This kit requires INVARA 0.2.0, but found {installed}; use a fresh environment")
        output = (args.output or (BASE / "runs" / (dt.datetime.now(dt.UTC).strftime("%Y%m%dT%H%M%SZ") + "-" + uuid.uuid4().hex[:8]))).resolve()
        output.mkdir(parents=True, exist_ok=False)
        run = ExampleRun(output)
        if args.workflow == "feature":
            result = feature(run, args.case == "changed")
        else:
            result = comparison(run, args.case == "changed", args.workflow == "handoff")
        result.update(schema="invara.kit.example-result/1", synthetic=True, customer_evidence=False,
                      kit_version=settings["version"], engine_version=installed,
                      python_version=sys.version.split()[0], platform=sys.platform,
                      engine_module_origin=importlib.util.find_spec("invara").origin,
                      operations=len(run.operations), independent_approval=False)
        write_json(output / "result.json", result)
        print(f"SYNTHETIC example only. Original engine verdict: {result['verdict']}")
        print(f"Declared example expectation observed: {result['expected_outcome_observed']}")
        print("This is not an independent review, a customer result, or approval to ship.")
        print(f"Local report and original receipts: {output}")
        return result["engine_exit_code"]
    except importlib.metadata.PackageNotFoundError:
        print("SETUP NEEDED: INVARA is not installed in this Python environment. Follow SETUP.md.", file=sys.stderr)
        return 3
    except (OSError, ValueError, KeyError, RuntimeError) as error:
        print(f"EXAMPLE NOT COMPLETED: {error}", file=sys.stderr)
        print("Keep any local receipts already written and read OUTCOMES.md. No completion is claimed.", file=sys.stderr)
        return 3

if __name__ == "__main__":
    raise SystemExit(main())
