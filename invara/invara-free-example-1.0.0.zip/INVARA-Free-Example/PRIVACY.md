# Your project stays on your computer

The offline guide has no scripts, analytics, cookies, forms, external fonts or
automatic requests. Links to package documentation and support open only if
you choose them. Those services handle ordinary connection or email details.

The example runner does not upload anything or call a remote model. It creates
a fresh run folder and runs only the small synthetic Python files included in
the selected example. It records local commands, output, paths, timestamps and
evidence. Those run folders can contain your local directory/user name. Keep
them private unless you have reviewed every file for sharing.

Installation from a package service is a separate network action. INVARA makes
no outbound network call itself, but commands or local services you put in your
own project plan run with your permissions and may access the network. INVARA
is not a sandbox. Never put secrets in a task plan or run an unread command.

No result is automatically posted, emailed, attached to a payment, or sent back
to MIGARYOS. For a recommendation, share https://migaryos.com/invara/ instead of
your project report. The website's separate optional measurement and the
payment provider's data handling are outside this offline kit.
