def greet(name: str) -> str:
    return f"Hello, {name}!"


def greet_many(names: list[str]) -> str:
    return " ".join(greet(name) for name in names)
