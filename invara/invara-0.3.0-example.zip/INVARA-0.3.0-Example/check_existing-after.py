from greet import greet

# This post-seal edit changes the protected bytes even though the check still passes.
assert greet("Mia") == "Hello, Mia!"
