from greet import greet_many

assert greet_many(["Mia", "Leo"]) == "Hello, Mia! Hello, Leo!"
