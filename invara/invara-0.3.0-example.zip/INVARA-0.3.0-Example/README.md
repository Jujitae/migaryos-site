# INVARA 0.3.0: two passing checks, two different verdicts

This is a synthetic teaching example executed on Windows with Python 3.12.10
and `invara==0.3.0`. It is not a customer project or a claim that INVARA
proves general correctness.

The feature adds `greet_many` while protecting the bytes of the existing
acceptance check. A contract is sealed **before** the feature is added. The
first judge records `PASS`: both checks exit 0 and the protected file is
unchanged. Then one comment is added to the protected file. Both checks still
exit 0, but the second judge records `BLOCK` for `constraint_breaks`.

In a fresh copy of this folder, run in PowerShell:

```powershell
py -3.12 -m venv .venv
.\.venv\Scripts\python.exe -m pip install invara==0.3.0
.\.venv\Scripts\python.exe -m invara seal task.json --db evidence.db --root .
Copy-Item greet-after.py greet.py
.\.venv\Scripts\python.exe -m invara judge invara-public-landing-example-030 --db evidence.db --root . --commit
Copy-Item check_existing-after.py check_existing.py
.\.venv\Scripts\python.exe -m invara judge invara-public-landing-example-030 --db evidence.db --root . --commit
.\.venv\Scripts\python.exe -m invara chain --db evidence.db --root .
.\.venv\Scripts\python.exe -m invara log invara-public-landing-example-030 --db evidence.db --root .
```

The second `judge` exits 1 because it reports `BLOCK`; that exit is expected.
Do not run these commands inside a real project. This folder contains only
synthetic example files and creates its own local `.venv` and `evidence.db`.

Observed on 2026-09-27 UTC with the public 0.3.0 package:

```text
PASS: 2 check(s) passed and 1 protected path(s) are unchanged
decided by: passed

BLOCK: 1 protected path(s) changed: check_existing.py: changed
decided by: constraint_breaks

chain: ok=true, contract=1, verdict=2, problems=[]
```

The observed verdict-chain head after those two judgments was
`597399c98a2889fe7246edf5331ebd567a3a7790941dec6bb09d8152e20129d1`.
Your fresh run will have different timestamps and hashes. The point to
compare is the verdict and reason, not the historical hash.
