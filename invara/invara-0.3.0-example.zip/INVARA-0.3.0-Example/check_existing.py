from greet import greet

assert greet("Mia") == "Hello, Mia!"
